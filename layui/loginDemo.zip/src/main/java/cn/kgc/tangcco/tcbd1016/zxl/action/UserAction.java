package cn.kgc.tangcco.tcbd1016.zxl.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

import com.alibaba.fastjson.JSON;

import cn.kgc.tangcco.tcbd1016.zxl.pojo.User;
@WebServlet(urlPatterns ="user.action")
public class UserAction extends HttpServlet{

private static final long serialVersionUID = 2858605561170239121L;

@Override
protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	String methodName = req.getParameter("methodName");
	
	if(!StringUtils.isEmpty(methodName)) {
		option(methodName,req,resp);
	}
}

private void option(String methodName, HttpServletRequest req, HttpServletResponse resp) throws IOException {
	switch (methodName) {
	case "login":
		login(req,resp);
		break;
	case "login2":
		login2(req,resp);
		break;
	default:
		break;
	}
	
}



private void login(HttpServletRequest req, HttpServletResponse resp) throws IOException {
	System.out.println("我是login1页面");
	//service 中的map
	Map<String, Object>map=new HashMap<String, Object>();
	map.put("status", "failed");
	//模拟数据库
	User user = new User();
	user.setAccount("admin");
	user.setPassword("123456");
	user.setNickname("吴成卓");
	//前端取值
	String account = req.getParameter("account");
	String password = req.getParameter("password");
	//设置响应字符集
	resp.setContentType("text/html;charset=utf-8");
	PrintWriter writer = resp.getWriter();
	
	if(StringUtils.equals(account, user.getAccount())&&StringUtils.equals(password, user.getPassword())) {
		map.put("status", "success");
		map.put("data", user);
	}
	writer.write(JSON.toJSONString(map));
	writer.flush();
	writer.close();
}


	private void login2(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		System.out.println("我是login2页面");
		//service 中的map
		Map<String, Object>map=new HashMap<String, Object>();
		map.put("status", "failed");
		//模拟数据库
		User user = new User();
		user.setAccount("admin");
		user.setPassword("123456");
		user.setNickname("吴成卓");
		//前端取值
		String account = req.getParameter("account");
		String password = req.getParameter("password");
		//设置响应字符集
		resp.setContentType("text/html;charset=utf-8");
		PrintWriter writer = resp.getWriter();
		
		if(StringUtils.equals(account, user.getAccount())&&StringUtils.equals(password, user.getPassword())) {
			map.put("status", "success");
			map.put("data", user);
		}
		//往session里面放数据  页面不关闭就是同一个会话。
		req.getSession().setAttribute("user", JSON.toJSONString(map));
		//this.getServletContext().getContextPath()获取上下文路径
		resp.sendRedirect(this.getServletContext().getContextPath()+"/main.jsp");
	}

	
	
	//总结
	/*页面1是用ajax提交的数据
	 * 可以把数据返回到main.html页面，也可以把数据返回到main.jsp页面
	 * 页面2是用form表单提交的数据
	 * 可以把数据返回到main.html页面，也可以把数据返回到main.jsp页面
	 * jsp页面可以引入js文件
	 * */
	
}
