$(()=>{
	let $strUser=sessionStorage.getItem("user")
	if($strUser==null){
		out()
	}
	let $user=JSON.parse($strUser)
	$('#nickname').text("操作者>>>"+$user.nickname)

})
function out(){
	location.replace("login1.html")
}