$(function(){
	$('#btn').click(()=>{
		let $account=$('#account').val()
		let $password=$('#password').val()
		if($account==""||$password==""){
			alert('不能是空')
			return
		}
		$.ajax({
			url:"/loginDemo/user.action?methodName=login",
			type:"post",
			dataType:"json",
			data:{"account":$account,"password":$password},
			success:function(q){
				switch (q.status){
					case "success":
					sessionStorage.setItem("user",JSON.stringify(q.data))
					location.replace('main.jsp')
						break;
					case "failed":
					alert('登录失败')
						break;
					default:
						break;
				}
			},
			error:function(){
				alert('走丢了')
			}
		})
	})
})