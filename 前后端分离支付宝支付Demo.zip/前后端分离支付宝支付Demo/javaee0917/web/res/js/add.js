

//获取后端服务器地址
$(function () {
    let $url = "";
    $.get('res/serverconfig.json', function (responseText, textStatus, XMLHttpRequest) {
        switch (textStatus) {
            case 'success':
                $url = responseText.protocol + responseText.domain + responseText.port + responseText.context;
                break;
            case 'error':
                layer.msg('走丢了', {
                    icon: 2,
                    shade: 0.01
                })
                break;
            default:
                break;
        }
    });


    //使用form模块
    layui.use(['form'], function () {
        var form = layui.form
 
        //提交
        form.on('submit(submit)', function (obj) {
           
            $.ajax({
                url: $url + '/user.action?methodName=alipay',
                type: "post",
                dataType: "json",
                data: { 'WIDtotal_amount': $('#WIDtotal_amount').val()},
                async:false,
                success: function (responseText) {
                    // alert(responseText)
                    // let p2 = window.document.getElementById("p2")
                    // // 浏览器会解析文根本中的html标签
                    // p2.innerHTML=responseText
                    // sessionStorage.setItem("form",JSON.stringify(responseText))
                    // location.replace("add2.html")
                    $('body').append(responseText);
                    // if(responseText.status){
                    // window.location.replace("add2.html")
                    // }
                    
                },
                error:function(){
                    alert('服务器走丢了')
                }
            })
           
        });
    });
})