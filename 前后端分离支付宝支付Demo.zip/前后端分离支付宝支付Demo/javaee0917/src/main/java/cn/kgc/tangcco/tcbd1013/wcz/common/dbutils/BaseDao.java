package cn.kgc.tangcco.tcbd1013.wcz.common.dbutils;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.commons.dbutils.DbUtils;

import com.mchange.v2.c3p0.ComboPooledDataSource;

/**
 * @author 李昊哲
 * @version 1.0 创建时间： 2019年7月8日 上午10:44:09 <br>
 *          类说明:
 */
public abstract class BaseDao {
	private static DataSource ds = new ComboPooledDataSource();
	// 线程本地变量
	private static ThreadLocal<Connection> tl = new ThreadLocal<Connection>();

	/**
	 * 获得c3p0连接池对象
	 * 
	 * @return 连接池对象
	 */
	public static DataSource getDataSource() {
		return ds;
	}

	/**
	 * 从线程中获取连接
	 * 
	 * @return Connection
	 * @throws SQLException
	 */
	public static Connection getConnection() throws SQLException {
		// 从线程中获取conneciton
		// 从tl中获取副本
		Connection conn = tl.get();
		// 如果是第一次从tl里取连接
		if (conn == null) {
			// 通过数据源获取连接
			conn = ds.getConnection();
			// 和当前线程绑定
			// 给tl中存放一个副本
			tl.set(conn);
		}
		return conn;
	}

	/**
	 * 开启事务（将自动提交方式 --→ 手动提交方式）
	 * 
	 * @throws SQLException
	 */
	public static void startTransaction() throws SQLException {
		getConnection().setAutoCommit(false); // true：自动 false:手动
	}

	/**
	 * 事务正常提交,且释放连接
	 * @throws SQLException 
	 */
	public static void commitAndClose() throws SQLException {
		// 事务提交并关闭资源
		DbUtils.commitAndClose(getConnection());
		// 解除绑定
		tl.remove();
	}

	/**
	 * 事务提交失败（异常），回滚且释放资源
	 * 
	 * @throws SQLException
	 */
	public static void rollbackAndClose() throws SQLException {
		// 事务回滚并关闭资源
		DbUtils.rollbackAndClose(getConnection());
		// 解除绑定
		tl.remove();
	}

	/**
	 * 关闭数据库链接
	 * 
	 * @throws SQLException
	 */
	public static void close() throws SQLException {
		getConnection().close();
		// 解除绑定
		tl.remove();
	}
}
