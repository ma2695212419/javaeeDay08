package cn.kgc.tangcco.tcbd1013.wcz.action.front;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;
import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.internal.util.AlipaySignature;
import com.alipay.api.request.AlipayTradePagePayRequest;

import cn.kgc.tangcco.tcbd1013.wcz.common.alipay.AlipayConfig;
import cn.kgc.tangcco.tcbd1013.wcz.common.alipay.IDUtils;
import cn.kgc.tangcco.tcbd1013.wcz.common.servlet.BaseServlet;
import cn.kgc.tangcco.tcbd1013.wcz.common.spring.ClassPathXmlApplicationContext;
import cn.kgc.tangcco.tcbd1013.wcz.service.front.UserService;

/**
 * @author 吴成卓
 * @version 1.0
 * 创建时间：	2019年8月28日 上午8:02:44
 */
@WebServlet(urlPatterns = "/user.action")
public class UserAction extends BaseServlet{
	
	private static final long serialVersionUID = -4548353287053794067L;
	private static ClassPathXmlApplicationContext ca=new ClassPathXmlApplicationContext("spring/ApplicationContext-service.xml");
	private static UserService userService=null;
	static {
		try {
			userService=(UserService) ca.getBean("userService");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void alipay(HttpServletRequest request, HttpServletResponse response) throws IOException {
		//获得初始化的AlipayClient
				AlipayClient alipayClient = new DefaultAlipayClient(AlipayConfig.gatewayUrl, AlipayConfig.app_id, AlipayConfig.merchant_private_key, "json", AlipayConfig.charset, AlipayConfig.alipay_public_key, AlipayConfig.sign_type);
				
				//设置请求参数
				AlipayTradePagePayRequest alipayRequest = new AlipayTradePagePayRequest();
				alipayRequest.setReturnUrl(AlipayConfig.return_url);
				alipayRequest.setNotifyUrl(AlipayConfig.notify_url);
				
				//商户订单号，商户网站订单系统中唯一订单号，必填
				String out_trade_no =IDUtils.createID();
				//付款金额，必填
				String total_amount = new String(request.getParameter("WIDtotal_amount").getBytes("ISO-8859-1"),"UTF-8");
				//订单名称，必填
				String subject = "支付宝第三方测试";
				//商品描述，可空
				String body = "!!!!!！";
				System.out.println(request.getParameter("WIDtotal_amount"));
				alipayRequest.setBizContent("{\"out_trade_no\":\""+ out_trade_no +"\"," 
						+ "\"total_amount\":\""+ total_amount +"\"," 
						+ "\"subject\":\""+ subject +"\"," 
						+ "\"body\":\""+ body +"\"," 
						+ "\"product_code\":\"FAST_INSTANT_TRADE_PAY\"}");
				
				//若想给BizContent增加其他可选请求参数，以增加自定义超时时间参数timeout_express来举例说明
				//alipayRequest.setBizContent("{\"out_trade_no\":\""+ out_trade_no +"\"," 
				//		+ "\"total_amount\":\""+ total_amount +"\"," 
				//		+ "\"subject\":\""+ subject +"\"," 
				//		+ "\"body\":\""+ body +"\"," 
				//		+ "\"timeout_express\":\"10m\"," 
				//		+ "\"product_code\":\"FAST_INSTANT_TRADE_PAY\"}");
				//请求参数可查阅【电脑网站支付的API文档-alipay.trade.page.pay-请求参数】章节
				
				//请求
				String result=null;
				try {
					result = alipayClient.pageExecute(alipayRequest).getBody();
				} catch (AlipayApiException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			    System.out.println(result);
			    //设置编码的方式为html
			    response.setContentType("text/html;charset=utf-8");
			    
			    //创建out的对象(打印) 打印出来支付宝给我们自动生成的表单在页面上
			    Map<String, Object>map=new HashMap<String, Object>();
			    response.getWriter().write(JSON.toJSONString(result));
		    
	}
	
	public void callBack(HttpServletRequest request, HttpServletResponse response) throws IOException, AlipayApiException {
		System.out.println("测试");

		
//			/**
//			 * 支付宝的回调 告诉你 1.支付宝订单号 2.自己商城生成的订单号 3.付款金额
//			 */

			// 商户订单号
			String out_trade_no = new String(request.getParameter("out_trade_no").getBytes("ISO-8859-1"), "UTF-8");

			// 支付宝交易号
			String trade_no = new String(request.getParameter("trade_no").getBytes("ISO-8859-1"), "UTF-8");

			// 付款金额
			String total_amount = new String(request.getParameter("total_amount").getBytes("ISO-8859-1"), "UTF-8");
			
			//设置相应的编码格式是 html
			response.setContentType("text/html;charset=utf-8");
			System.out.println("订单号:"+out_trade_no);
			System.out.println("支付宝交易号"+trade_no);
			System.out.println("付款金额"+total_amount);
			
			response.sendRedirect("http://127.0.0.1:5500/show.html");
	}
	
}
