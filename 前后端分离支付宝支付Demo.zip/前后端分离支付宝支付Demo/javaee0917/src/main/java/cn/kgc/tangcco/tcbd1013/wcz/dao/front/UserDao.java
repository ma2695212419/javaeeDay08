package cn.kgc.tangcco.tcbd1013.wcz.dao.front;

import java.sql.SQLException;

import cn.kgc.tangcco.tcbd1013.wcz.pojo.User;

/**
 * @author 吴成卓
 * @version 1.0
 * 创建时间：	2019年8月27日 下午8:05:30
 */
public interface UserDao {
	
}
