package cn.kgc.tangcco.tcbd1013.wcz.common.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.lang.reflect.Method;
import java.util.Optional;

import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

/**
 * Servlet implementation class BaseServlet
 */
public class BaseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public BaseServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String methodName = Optional.ofNullable(request.getParameter("methodName")).orElse("");
		if (StringUtils.isNotEmpty(methodName)) {
			try {
				if (StringUtils.isNotEmpty(request.getHeader("content-type"))) {
					if (getContentType(request).contains("application/json")
							|| getContentType(request).contains("text/plain")) {
						// ajax方式
						BufferedReader br = new BufferedReader(
								new InputStreamReader((ServletInputStream) request.getInputStream(), "utf-8"));
						StringBuffer sb = new StringBuffer();
						String temp;
						while ((temp = br.readLine()) != null) {
							sb.append(temp);
						}
						br.close();
						Method method = this.getClass().getDeclaredMethod(methodName, HttpServletRequest.class,
								HttpServletResponse.class, String.class);
						method.setAccessible(true);
						method.invoke(this, request, response, sb.toString());
					} else {
						// 传统表单方式
						Method method = this.getClass().getDeclaredMethod(methodName, HttpServletRequest.class,
								HttpServletResponse.class);
						method.setAccessible(true);
						method.invoke(this, request, response);
					}

				} else {
					// RequertHeader中没有Content-Type 使用传统表单方式
					Method method = this.getClass().getDeclaredMethod(methodName, HttpServletRequest.class,
							HttpServletResponse.class);
					method.setAccessible(true);
					method.invoke(this, request, response);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	private String getContentType(HttpServletRequest request) {
		Optional<String> ofNullable = Optional.ofNullable(request.getHeader("content-type"));
		return ofNullable.orElse("");
	}

	public void print(HttpServletRequest request, HttpServletResponse response, String json) {
		PrintWriter printWriter = null;
		try {
			printWriter = response.getWriter();
			printWriter.println(json);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
		} finally {
			printWriter.flush();
			printWriter.close();
		}
	}

	public void forword(HttpServletRequest request, HttpServletResponse response, String path) {
		try {
			request.getRequestDispatcher(path).forward(request, response);
			return;
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void redirect(HttpServletRequest request, HttpServletResponse response, String location) {
		try {
			response.sendRedirect(location);
			return;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
