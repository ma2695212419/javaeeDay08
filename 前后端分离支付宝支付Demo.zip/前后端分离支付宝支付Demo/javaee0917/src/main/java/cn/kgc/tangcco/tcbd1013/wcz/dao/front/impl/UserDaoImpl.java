package cn.kgc.tangcco.tcbd1013.wcz.dao.front.impl;

import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;

import cn.kgc.tangcco.tcbd1013.wcz.common.dbutils.BaseDao;
import cn.kgc.tangcco.tcbd1013.wcz.dao.front.UserDao;
import cn.kgc.tangcco.tcbd1013.wcz.pojo.User;

/**
 * @author 吴成卓
 * @version 1.0
 * 创建时间：	2019年8月27日 下午8:06:57
 */
public class UserDaoImpl implements UserDao{
	private QueryRunner queryRunner=new QueryRunner();
	

}
