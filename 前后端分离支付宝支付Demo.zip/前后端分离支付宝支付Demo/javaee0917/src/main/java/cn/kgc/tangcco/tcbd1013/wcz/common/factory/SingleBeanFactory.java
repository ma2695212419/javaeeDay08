package cn.kgc.tangcco.tcbd1013.wcz.common.factory;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

import cn.kgc.tangcco.tcbd1013.wcz.common.xml.XmlUtil;


/**
 * @author 李昊哲
 * @version 1.0 创建时间： 2019年7月1日 上午10:57:37 <br>
 *          类说明:
 */
public class SingleBeanFactory  extends XmlUtil{
	
	private static SingleBeanFactory instance = new SingleBeanFactory();
	
	private Map<String, Object> map = new HashMap<String, Object>();

	private SingleBeanFactory() {

	}

	/**
	 * @return the instance
	 */
	public static SingleBeanFactory getInstance() {
		return instance;
	}
	
	public Object  newInstance(String beanId,String beanClass) {
		if (map.containsKey(beanId)) {
			return map.get(beanId);
		}
		try {
			Object value = Class.forName(beanClass).getDeclaredConstructor().newInstance();
			map.put(beanId, value);
			return value;
		} catch (ClassNotFoundException | SecurityException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
