package cn.kgc.tangcco.tcbd1013.wcz.service.front.impl;
/**
 * @author 吴成卓
 * @version 1.0
 * 创建时间：	2019年8月27日 下午8:20:44
 */

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import cn.kgc.tangcco.tcbd1013.wcz.common.dbutils.BaseDao;
import cn.kgc.tangcco.tcbd1013.wcz.common.spring.ClassPathXmlApplicationContext;
import cn.kgc.tangcco.tcbd1013.wcz.dao.front.UserDao;
import cn.kgc.tangcco.tcbd1013.wcz.pojo.User;
import cn.kgc.tangcco.tcbd1013.wcz.service.front.UserService;

public class UserServiceImpl implements UserService{
	private static ClassPathXmlApplicationContext ca=new ClassPathXmlApplicationContext("spring/ApplicationContext-dao.xml");
	private static UserDao userDao=null;
	static {
		try {
			userDao=(UserDao) ca.getBean("userDao");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
