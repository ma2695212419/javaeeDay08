package cn.kgc.tangcco.tcbd1013.wcz.dao.front;
/**
 * @author 吴成卓
 * @version 1.0
 * 创建时间：	2019年8月27日 下午8:12:42
 */

import java.sql.SQLException;

import org.junit.Test;

import cn.kgc.tangcco.tcbd1013.wcz.common.dbutils.BaseDao;
import cn.kgc.tangcco.tcbd1013.wcz.common.spring.ClassPathXmlApplicationContext;
import cn.kgc.tangcco.tcbd1013.wcz.pojo.User;

public class UserDaoTest {
	private static ClassPathXmlApplicationContext ca=new ClassPathXmlApplicationContext("spring/ApplicationContext-dao.xml");
	private static UserDao userDao=null;
	static {
		try {
			userDao=(UserDao) ca.getBean("userDao");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
//	@Test
//	public void test01() {
//		try {
//			BaseDao.startTransaction();
//			int inserteUser = userDao.inserteUser(new User("admin", "19919990911"));
//			System.out.println(inserteUser);
//			BaseDao.commitAndClose();
//		} catch (SQLException e) {
//			try {
//				BaseDao.rollbackAndClose();
//			} catch (SQLException e1) {
//				// TODO Auto-generated catch block
//				e1.printStackTrace();
//			}
//			e.printStackTrace();
//		}
//	}
}
