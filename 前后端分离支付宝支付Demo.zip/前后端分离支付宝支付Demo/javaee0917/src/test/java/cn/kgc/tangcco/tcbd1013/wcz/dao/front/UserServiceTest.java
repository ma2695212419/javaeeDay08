package cn.kgc.tangcco.tcbd1013.wcz.dao.front;
/**
 * @author 吴成卓
 * @version 1.0
 * 创建时间：	2019年8月27日 下午8:25:10
 */

import java.util.Map;

import org.junit.Test;

import cn.kgc.tangcco.tcbd1013.wcz.common.spring.ClassPathXmlApplicationContext;
import cn.kgc.tangcco.tcbd1013.wcz.pojo.User;
import cn.kgc.tangcco.tcbd1013.wcz.service.front.UserService;

public class UserServiceTest {
	private static ClassPathXmlApplicationContext ca=new ClassPathXmlApplicationContext("spring/ApplicationContext-service.xml");
	private static UserService userService=null;
	static {
		try {
			userService=(UserService) ca.getBean("userService");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
//	@Test
//	public void test01() {
//		Map<String, Object> addUser = userService.addUser(new User("admin1", "19919990911"));
//		System.out.println(addUser.get("status").toString());
//	}
}
