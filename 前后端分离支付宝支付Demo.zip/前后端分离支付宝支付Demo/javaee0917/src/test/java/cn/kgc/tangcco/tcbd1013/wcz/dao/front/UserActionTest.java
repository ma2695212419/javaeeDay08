package cn.kgc.tangcco.tcbd1013.wcz.dao.front;

import java.util.Random;

import org.junit.Test;

import cn.kgc.tangcco.tcbd1013.wcz.action.front.UserAction;

/**
 * @author 吴成卓
 * @version 1.0
 * 创建时间：	2019年8月28日 上午9:57:05
 */
public class UserActionTest {
	
}
